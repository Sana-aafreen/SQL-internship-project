-- schema.sql
-- PostgreSQL schema for LMS


CREATE DATABASE EXTENSION;
USE EXTENSION;

-- STUDENTS
CREATE TABLE students (
  student_id CHAR(36) NOT NULL,        -- store UUID as string
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  date_of_birth DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (student_id)
);

-- INSTRUCTIONS
CREATE TABLE instructors (
  instructor_id CHAR(36) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  hire_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (instructor_id)
);

-- COURSES
CREATE TABLE courses (
  course_id CHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  code VARCHAR(50) NOT NULL UNIQUE,
  description TEXT,
  start_date DATE,
  end_date DATE,
  instructor_id CHAR(36) NOT NULL,
  PRIMARY KEY (course_id),
  FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id) ON DELETE RESTRICT
);

-- MODULES (Lessons)
CREATE TABLE modules (
  module_id CHAR(36) NOT NULL,
  course_id CHAR(36) NOT NULL,
  title VARCHAR(255) NOT NULL,
  position INT NOT NULL,
  content_url VARCHAR(1000),
  duration_minutes INT DEFAULT 0,
  PRIMARY KEY (module_id),
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
  UNIQUE (course_id, position)
);

-- ENROLLMENTS
CREATE TABLE enrollments (
  enrollment_id CHAR(36) NOT NULL,
  student_id CHAR(36) NOT NULL,
  course_id CHAR(36) NOT NULL,
  enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(20) NOT NULL DEFAULT 'active', -- active, completed, dropped
  PRIMARY KEY (enrollment_id),
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
  UNIQUE (student_id, course_id)
);

-- GRADES
CREATE TABLE grades (
  grade_id CHAR(36) NOT NULL,
  enrollment_id CHAR(36) NOT NULL,
  module_id CHAR(36) NOT NULL,
  score DECIMAL(5,2) CHECK (score >= 0 AND score <= 100),
  graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (grade_id),
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id) ON DELETE CASCADE,
  FOREIGN KEY (module_id) REFERENCES modules(module_id) ON DELETE CASCADE,
  UNIQUE (enrollment_id, module_id)
);

-- ATTENDANCE
CREATE TABLE attendance (
  attendance_id CHAR(36) NOT NULL,
  enrollment_id CHAR(36) NOT NULL,
  module_id CHAR(36) NOT NULL,
  present BOOLEAN NOT NULL,
  recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (attendance_id),
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id) ON DELETE CASCADE,
  FOREIGN KEY (module_id) REFERENCES modules(module_id) ON DELETE CASCADE,
  UNIQUE (enrollment_id, module_id, recorded_at)
);

-- Indexes for performance (foreign keys and common filters)
CREATE INDEX idx_enrollments_student ON enrollments(student_id);
CREATE INDEX idx_enrollments_course ON enrollments(course_id);
CREATE INDEX idx_modules_course_pos ON modules(course_id, position);
CREATE INDEX idx_grades_enrollment ON grades(enrollment_id);
CREATE INDEX idx_grades_module ON grades(module_id);
CREATE INDEX idx_attendance_enrollment ON attendance(enrollment_id);
CREATE INDEX idx_attendance_module ON attendance(module_id);

-- Sample helper view: modules per course
CREATE VIEW course_module_count AS
SELECT c.course_id, c.title, COUNT(m.module_id) AS module_count
FROM courses c
LEFT JOIN modules m ON c.course_id = m.course_id
GROUP BY c.course_id, c.title;

INSERT INTO students (student_id, first_name, last_name, email, date_of_birth)
SELECT UUID(),
  SUBSTRING_INDEX(name, ' ', 1),
  SUBSTRING_INDEX(name, ' ', -1),
  CONCAT(LOWER(SUBSTRING_INDEX(name, ' ', 1)), '.', LOWER(SUBSTRING_INDEX(name, ' ', -1)), n, '@student.example'),
  DATE_ADD('1995-01-01', INTERVAL FLOOR(RAND()*5000) DAY)
FROM (
  SELECT 1 AS n, 'Sana Ahmed' AS name UNION ALL
  SELECT 2, 'Li Mei' UNION ALL
  SELECT 3, 'Oliver Jones' UNION ALL
  SELECT 4, 'Emma Brown' UNION ALL
  SELECT 5, 'Noah Lee' UNION ALL
  SELECT 6, 'Ava Patel' UNION ALL
  SELECT 7, 'Mason Davis' UNION ALL
  SELECT 8, 'Sophia Taylor' UNION ALL
  SELECT 9, 'Liam Martin' UNION ALL
  SELECT 10, 'Mia Thompson'
) t;
-- Repeat or use a numbers table to reach 60 rows

INSERT INTO courses (course_id, title, code, description, start_date, end_date, instructor_id)
SELECT UUID(),
  CONCAT('Course ', n, ' — Intro to Topic ', n),
  CONCAT('C', LPAD(n, 3, '0')),
  CONCAT('Description for course ', n),
  DATE_ADD('2025-01-01', INTERVAL n*7 DAY),
  DATE_ADD('2025-01-01', INTERVAL n*7+60 DAY),
  (SELECT instructor_id FROM instructors ORDER BY RAND() LIMIT 1)
FROM (
  SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5
  UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10
  UNION ALL SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15
) nums;

INSERT INTO instructors (instructor_id, first_name, last_name, email, hire_date, created_at)
VALUES 
  (UUID(), 'Alice', 'Johnson', 'alice.johnson@lms.com', '2020-05-01', NOW()),
  (UUID(), 'Bob', 'Smith', 'bob.smith@lms.com', '2019-03-15', NOW()),
  (UUID(), 'Carla', 'Lopez', 'carla.lopez@lms.com', '2021-08-10', NOW()),
  (UUID(), 'David', 'Brown', 'david.brown@lms.com', '2018-07-20', NOW()),
  (UUID(), 'Elena', 'Wong', 'elena.wong@lms.com', '2022-01-25', NOW()),
  (UUID(), 'Farhan', 'Ali', 'farhan.ali@lms.com', '2020-09-30', NOW()),
  (UUID(), 'Grace', 'Miller', 'grace.miller@lms.com', '2017-04-12', NOW()),
  (UUID(), 'Hiro', 'Tanaka', 'hiro.tanaka@lms.com', '2021-11-05', NOW()),
  (UUID(), 'Isabella', 'Martinez', 'isabella.martinez@lms.com', '2019-02-18', NOW()),
  (UUID(), 'James', 'Wilson', 'james.wilson@lms.com', '2023-06-01', NOW());

INSERT INTO courses (course_id, title, code, description, start_date, end_date, instructor_id)
SELECT UUID(),
  CONCAT('Course ', n, ' — Intro to Topic ', n),
  CONCAT('C', LPAD(n, 3, '0')),
  CONCAT('Description for course ', n),
  DATE_ADD('2025-01-01', INTERVAL n*7 DAY),
  DATE_ADD('2025-01-01', INTERVAL n*7+60 DAY),
  (SELECT instructor_id FROM instructors ORDER BY RAND() LIMIT 1)
FROM (
  SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5
  UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10
  UNION ALL SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15
) nums;

INSERT INTO modules (module_id, course_id, title, position, content_url, duration_minutes)
SELECT UUID(),
       c.course_id,
       CONCAT(c.title, ' — Module ', n),
       n,
       CONCAT('https://content.example.edu/', c.code, '/module/', n),
       FLOOR(20 + (RAND() * 80))
FROM courses c
JOIN (
  SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL 
  SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
) numbers
ON RAND() < 0.8; -- ~80% of courses get 6 modules, some less


-- Sample helper view: modules per course

SELECT c.course_id, c.title, COUNT(m.module_id) AS module_count
FROM courses c
LEFT JOIN modules m ON c.course_id = m.course_id
GROUP BY c.course_id, c.title;

